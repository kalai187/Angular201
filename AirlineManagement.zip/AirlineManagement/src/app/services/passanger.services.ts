import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Passanger } from '../Model/passanger.model';

@Injectable()
export class PassengerService{

    constructor(private http: HttpClient){}

    getPassangerList(){
        return this.http.get('/api/Passangers_detail/');
    }

    getPassangerById(id: number){
       return this.http.get('/api/Passangers_detail/'+id);
    }

    updatePassangerById(index: number, passanger: Passanger){
        return this.http.put('/api/Passangers_detail/'+index, passanger);
    }

    createPassanger(passanger: Passanger){
        return this.http.post('/api/Passangers_detail', passanger);
    }

    getPassangerByFlightId(fid: string){
        return this.http.get('/api/Passangers_detail?flight_id='+fid);
    }

    getPassangerByPid(pid: string){
        return this.http.get('/api/Passangers_detail?seat_number='+pid);
    }

}