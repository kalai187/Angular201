import { HttpClient } from '@angular/common/http';
import { Flight } from '../Model/flight.model';
import { identifierModuleUrl } from '@angular/compiler';


export class FlightServices{

    constructor(private http: HttpClient){}

    getFlightList(){
    return this.http.get('api/Flights_detail');
    }

    getFlightById(index: number){
        return this.http.get('/api/Flights_detail/'+index);
    }
    updateFlight(id: number, flight: Flight){
        return this.http.put('/api/Flights_detail/'+id, flight);
    }

}