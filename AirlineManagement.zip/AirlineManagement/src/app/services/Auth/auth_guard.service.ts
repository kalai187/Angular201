import { Injectable } from '@angular/core';
import { CanActivate, Router, CanActivateChild } from '@angular/router';
import { LoginServices } from '../login.service';

@Injectable()
export class AuthGuard implements CanActivate, CanActivateChild {
  constructor(public login: LoginServices, public router: Router) {}
  canActivate(): boolean {
    if (this.login.loginStatus == "LogOut") {
      return true;
    }else{
        this.router.navigate(['login']);
        return false;
    }
  }

  canActivateChild(): boolean {
    if (this.login.loginStatus == "LogOut") {
      return true;
    }else{
        this.router.navigate(['login']);
        return false;
    }
    
  }
}