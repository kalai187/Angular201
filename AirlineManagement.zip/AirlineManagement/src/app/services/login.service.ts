
export class LoginServices{

    loginStatus: string = "Login";

    socialLogin: boolean = false;

    changeLoginStatus(status: string){
        this.loginStatus = status;
    }
    changeSocialLogin(login: boolean){
        this.socialLogin = login;
    }

}