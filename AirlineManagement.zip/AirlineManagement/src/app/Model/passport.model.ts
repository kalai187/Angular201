export interface Passport{
    passport_number: string;
    pan_card: string;
    expire_date: string;
}