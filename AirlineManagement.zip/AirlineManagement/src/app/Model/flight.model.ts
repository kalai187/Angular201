import { Ancillary } from './ancillary.model';
import { Food } from './food.model';
import { ShoopingItem } from './shopping-item.model';

export interface Flight{
    id: number;
    flight_id: string,
    name: string;
    route: string;
    departure: string;
    arrival: string;
    price: number;
    ancillary: Ancillary;
    food: Food;
    shoppingItems: ShoopingItem[];

}