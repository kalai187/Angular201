import { Passport } from './passport.model';
import { Food } from './food.model';
import { ShoopingItem } from './shopping-item.model';
import { Address } from './address.model';
import { Ancillary } from './ancillary.model';

export interface Passanger{
    id: number;
    name: string;
    birth_date: string
    seat_number: string;
    checked_in: boolean;
    infant: boolean;
    wheel_chair: boolean;
    passport_detail: Passport;
    ancillary: Ancillary;
    address: Address;
    food: Food;
    shopping_items: ShoopingItem[];
    flight_id: string;
    

    
}