export interface Food{

}