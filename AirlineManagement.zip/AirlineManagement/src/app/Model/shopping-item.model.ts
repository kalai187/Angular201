export class ShoopingItem{
    item : string;
    quantity: number;
    price: number;
}