import { PipeTransform, Pipe } from '@angular/core';

@Pipe({name: 'repeat'})
export class IteratePipe implements PipeTransform {
    transform(value: any, args: any[] = null): any {
        return Object.keys(value).map(key => Object.assign({ key }, value[key]));
        
    }
}