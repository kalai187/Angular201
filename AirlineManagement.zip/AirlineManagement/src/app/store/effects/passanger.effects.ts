import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';

import { PassengerService } from '../../services/passanger.services';
import * as passangerActions from '../actions/passanger.actions';
import { Observable } from 'rxjs';
import { Action } from '@ngrx/store';
import { mergeMap, map } from 'rxjs/operators';
import { Passanger } from 'src/app/model/passanger.model';

@Injectable()
export class PassangerEffects{

    constructor(
        private actions$ : Actions,
        private passangerService: PassengerService
    ){}

    @Effect()
    loadPassangers$: Observable<Action> = this.actions$.pipe(
        ofType<passangerActions.LoadPassangers>(
            passangerActions.EPassangerAction.LOAD_PASSANGERS
        ),
        mergeMap((actions:passangerActions.LoadPassangers)=>
        this.passangerService.getPassangerList().pipe(
            map(
                (passangers: Passanger[]) =>
                new passangerActions.LoadPassangersSuccess(passangers))
        )
    )
  );

  @Effect()
    loadPassangersByFlight$: Observable<Action> = this.actions$.pipe(
        ofType<passangerActions.LoadPassangersByFlightId>(
            passangerActions.EPassangerAction.LOAD_PASSANGERS_BY_FLIGHT_ID
        ),
        mergeMap((actions:passangerActions.LoadPassangersByFlightId)=>
        this.passangerService.getPassangerByFlightId(actions.payload).pipe(
            map(
                (passangers: Passanger[]) =>
                new passangerActions.LoadPassangersByFlightIdSuccess(passangers))
        )
    )
  );

  @Effect()
  loadPassanger$: Observable<Action> = this.actions$.pipe(
      ofType<passangerActions.LoadPassanger>(
          passangerActions.EPassangerAction.LOAD_PASSANGER
      ),
      mergeMap((action: passangerActions.LoadPassanger) => 
        this.passangerService.getPassangerById(action.payload).pipe(
            map(
               (passanger: Passanger) => 
                    new passangerActions.LoadPassangerSuccess(passanger))
        )
      )
        
  );

  @Effect()
  updatePassanger$: Observable<Action> = this.actions$.pipe(
      ofType<passangerActions.UpdatePassanger>(
          passangerActions.EPassangerAction.UPDATE_PASSANGER
      ),
      mergeMap((action: passangerActions.UpdatePassanger) => 
        this.passangerService.updatePassangerById(action.id, action.payload).pipe(
            map(
               (passanger: Passanger) => 
                    new passangerActions.UpdatePassangerSuccess(passanger))
        )
      )
        
  );

  @Effect()
  createPassanger$: Observable<Action> = this.actions$.pipe(
      ofType<passangerActions.CreatePassanger>(
          passangerActions.EPassangerAction.CREATE_PASSANGER
      ),
      mergeMap((action: passangerActions.CreatePassanger) => 
        this.passangerService.createPassanger(action.payload).pipe(
            map(
               (passanger: Passanger) => 
                    new passangerActions.UpdatePassangerSuccess(passanger))
        )
      )
        
  );

  @Effect()
  loadPassangerByPid$: Observable<Action> = this.actions$.pipe(
      ofType<passangerActions.LoadPassangerByPID>(
          passangerActions.EPassangerAction.LOAD_PASSANGER_BY_PID
      ),
      mergeMap((action: passangerActions.LoadPassangerByPID) => 
        this.passangerService.getPassangerByPid(action.payload).pipe(
            map(
               (passanger: Passanger) => 
                    new passangerActions.LoadPassangerByPIDSuccess(passanger))
        )
      )
        
  );


}