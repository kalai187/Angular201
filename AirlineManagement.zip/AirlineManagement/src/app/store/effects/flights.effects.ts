import { Injectable } from '@angular/core';
import { Action } from '@ngrx/store';
import { FlightServices } from 'src/app/services/flight.services';
import { Effect, ofType, Actions } from '@ngrx/effects';
import { Observable, of } from 'rxjs';
import * as flightActions from '../actions/flights.actions';
import { mergeMap, map } from 'rxjs/operators';
import { Flight } from 'src/app/model/flight.model';

@Injectable()
export class FlightEffect{

    constructor(
        private actions$ : Actions,
        private flightService: FlightServices
    ){}

    @Effect()
    loadFlights$: Observable<Action> = this.actions$.pipe(
        ofType<flightActions.LoadFlights>(
            flightActions.EFlightActions.LOAD_FLIGHTS
        ),
        mergeMap((actions:flightActions.LoadFlights)=>
        this.flightService.getFlightList().pipe(
            map(
                (flights: Flight[]) =>
                new flightActions.LoadFlightsSuccess(flights))
        )
    )
  );

  @Effect()
  loadFlight$: Observable<Action> = this.actions$.pipe(
      ofType<flightActions.LoadFlight>(
          flightActions.EFlightActions.LOAD_FLIGHT
      ),
      mergeMap((action: flightActions.LoadFlight) => 
        this.flightService.getFlightById(action.payload).pipe(
            map(
               (flight: Flight) => 
                    new flightActions.LoadFlightSuccess(flight))
        )
      )
        
  )

  @Effect()
  updateFlight$: Observable<Action> = this.actions$.pipe(
      ofType<flightActions.UpdateFlight>(
          flightActions.EFlightActions.UPDATE_FLIGHT
      ),
      mergeMap((action: flightActions.UpdateFlight) => 
        this.flightService.updateFlight(action.id, action.payload).pipe(
            map(
               (flight: Flight) => 
                    new flightActions.UpdateFlightSuccess(flight))
        )
      )
        
  )
}