import { Action } from '@ngrx/store';
import { Passanger } from 'src/app/model/passanger.model';
import { Flight } from 'src/app/Model/flight.model';


export enum EPassangerAction{
    LOAD_PASSANGERS = '[Passanger] Load Passangers',
    LOAD_PASSANGERS_SUCCESS = '[Passanger] Load Passangers Success',
    LOAD_PASSANGER = '[Passanger] Load Passanger',
    LOAD_PASSANGER_SUCCESS = '[Passanger] Load Passanger Success',
    UPDATE_PASSANGER = '[Passanger] Update Passanger',
    UPDATE_PASSANGER_SUCCESS = '[Passanger] Update Passanger Success',
    LOAD_PASSANGERS_BY_FLIGHT_ID = '[Passanger] Load Passangers By Flight Id',
    LOAD_PASSANGERS_BY_FLIGHT_ID_SUCCESS = '[Passanger] Load Passangers By Flight Id Success',
    CREATE_PASSANGER = '[Passanger] Create Passanger',
    CREATE_PASSANGER_SUCCESS = '[Passanger] Create Passanger',
    LOAD_PASSANGER_BY_PID = '[Passanger] Load Passanger By PID',
    LOAD_PASSANGER_BY_PID_SUCCESS = '[Passanger] Load Passanger By PID Success'

}

export class LoadPassangerByPID implements Action{
    readonly type = EPassangerAction.LOAD_PASSANGER_BY_PID;

    constructor(public payload: string){}
}

export class LoadPassangerByPIDSuccess implements Action{
    readonly type = EPassangerAction.LOAD_PASSANGER_BY_PID_SUCCESS;

    constructor(public payload: Passanger){}
}

export class CreatePassanger implements Action{
    readonly type = EPassangerAction.CREATE_PASSANGER;

    constructor(public payload: Passanger){}
}

export class CreatePassangerSuccess implements Action{
    readonly type = EPassangerAction.CREATE_PASSANGER_SUCCESS;

    constructor(public payload: Passanger){}
}

export class LoadPassangersByFlightId implements Action{
    readonly type = EPassangerAction.LOAD_PASSANGERS_BY_FLIGHT_ID;

    constructor(public payload: string){}
}

export class LoadPassangersByFlightIdSuccess implements Action{
    readonly type = EPassangerAction.LOAD_PASSANGERS_BY_FLIGHT_ID_SUCCESS;

    constructor(public payload: Passanger[]){}
}

export class LoadPassangers implements Action{
    readonly type = EPassangerAction.LOAD_PASSANGERS;
}

export class LoadPassangersSuccess implements Action{
    readonly type = EPassangerAction.LOAD_PASSANGERS_SUCCESS;

    constructor(public payload: Passanger[]){}
}

export class LoadPassanger implements Action{
    readonly type = EPassangerAction.LOAD_PASSANGER;
    constructor(public payload: number){}
}

export class LoadPassangerSuccess implements Action{
    readonly type = EPassangerAction.LOAD_PASSANGER_SUCCESS;

    constructor(public payload: Passanger){}
}

export class UpdatePassanger implements Action{
    readonly type = EPassangerAction.UPDATE_PASSANGER;
    constructor(public id: number, public payload: Passanger){}
}

export class UpdatePassangerSuccess implements Action{
    readonly type = EPassangerAction.UPDATE_PASSANGER_SUCCESS;
    constructor(public payload: Passanger){}
}

export type PassangerActions =  LoadPassangers | LoadPassangersSuccess | LoadPassanger|
                                LoadPassangerSuccess | UpdatePassanger | UpdatePassangerSuccess|
                                LoadPassangersByFlightId | LoadPassangersByFlightIdSuccess|
                                CreatePassanger | CreatePassangerSuccess | LoadPassangerByPID |
                                LoadPassangerByPIDSuccess;