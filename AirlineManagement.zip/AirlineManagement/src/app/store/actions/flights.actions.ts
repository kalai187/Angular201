import { Action } from '@ngrx/store';
import { Flight } from 'src/app/model/flight.model';

export enum EFlightActions{
    LOAD_FLIGHTS = "[Flight] Load Filghts",
    LOAD_FLIGHTS_SUCCESS = "[Flight] Load Filghts Success",
    LOAD_FLIGHT = "[Flight] Load Flight",
    LOAD_FLIGHT_SUCCESS = "[Flight] Load Flight Success",
    UPDATE_FLIGHT = "[Flight] Update Flight",
    UPDATE_FLIGHT_SUCCESS = "[Flight] Update Flight Success",
    DELETE_FLIGHT = "[Flight] Delete Flight",
    DELETE_FLIGHT_SUCCESS = "[Flight] Delete Flight Success"
}

export class DeleteFlight implements Action{
    readonly type = EFlightActions.DELETE_FLIGHT;
    constructor(public payload: number){}
}

export class DeleteFlightSuccess implements Action{
    readonly type = EFlightActions.DELETE_FLIGHT_SUCCESS;
    constructor(public payload: Flight[]){}
}

export class UpdateFlight implements Action{
    readonly type = EFlightActions.UPDATE_FLIGHT;
    constructor(public id: number, public payload: Flight){}
}

export class UpdateFlightSuccess implements Action{
    readonly type = EFlightActions.UPDATE_FLIGHT_SUCCESS;
    constructor(public payload: Flight){}
}

export class LoadFlights implements Action{
    readonly type = EFlightActions.LOAD_FLIGHTS;
}
export class LoadFlightsSuccess implements Action{
    readonly type = EFlightActions.LOAD_FLIGHTS_SUCCESS;

    constructor(public payload: Flight[]){}
}

export class LoadFlight implements Action{
    readonly type = EFlightActions.LOAD_FLIGHT;
    constructor(public payload: number){}
}
export class LoadFlightSuccess implements Action{
    readonly type = EFlightActions.LOAD_FLIGHT_SUCCESS;

    constructor(public payload: Flight){}
}


export type FlightAction = LoadFlights | LoadFlightsSuccess | LoadFlight | LoadFlightSuccess |
                            UpdateFlight | UpdateFlightSuccess | DeleteFlight | DeleteFlightSuccess;