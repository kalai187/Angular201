import { IFlightState, initialFlightState } from './flight.state';
import { IPassangerState, initialPassangerState } from './passanger.state';

export interface IAppState{
    flights: IFlightState;
    passangers: IPassangerState;
}

export const initialAppState: IAppState = {
    flights: initialFlightState,
    passangers: initialPassangerState
}

export function getInitialState(): IAppState{
    return initialAppState;
}