import { Flight } from 'src/app/model/flight.model';

export interface IFlightState{
    flights: Flight[];
    flight: Flight;
}

export const initialFlightState: IFlightState = {
    flights: null,
    flight: null
}