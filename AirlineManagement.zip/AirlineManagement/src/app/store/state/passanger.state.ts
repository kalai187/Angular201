import { Passanger } from 'src/app/model/passanger.model';

export interface IPassangerState{
    passangers: Passanger[];
    passanger: Passanger;
}

export const initialPassangerState: IPassangerState = {
    passangers: null,
    passanger: null
}