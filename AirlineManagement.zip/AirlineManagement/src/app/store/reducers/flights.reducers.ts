import * as flightActions from '../actions/flights.actions';
import { initialFlightState, IFlightState } from '../state/flight.state';



export function flightReducer(
    state = initialFlightState,
    action: flightActions.FlightAction
): IFlightState {
    switch (action.type){
        case flightActions.EFlightActions.LOAD_FLIGHTS_SUCCESS: {
            return {
                ...state,
                flights: action.payload
            };
        }
        case flightActions.EFlightActions.LOAD_FLIGHT_SUCCESS: {
            return {
                ...state,
                flight: action.payload
            };
        }
        case flightActions.EFlightActions.UPDATE_FLIGHT_SUCCESS: {
            return {
                ...state,
                flight: action.payload
            };
        }
        default: {
            return state;
        
        }
            
    }
}
{

}

