import { ActionReducerMap } from '@ngrx/store';
import { IAppState } from '../state/app.state';
import { flightReducer } from './flights.reducers';
import { passangerReducer } from './passanger.reducers';

export const appReducers: ActionReducerMap<IAppState, any> = {
    flights: flightReducer,
    passangers: passangerReducer
}