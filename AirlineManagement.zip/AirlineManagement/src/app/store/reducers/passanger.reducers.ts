import { initialPassangerState, IPassangerState } from '../state/passanger.state';
import * as passangerActions from '../actions/passanger.actions';
import { Action } from 'rxjs/internal/scheduler/Action';

export function passangerReducer(
    state = initialPassangerState,
    action: passangerActions.PassangerActions
): IPassangerState{
    switch (action.type){
        case passangerActions.EPassangerAction.LOAD_PASSANGERS_SUCCESS: {
            return {
                ...state,
                passangers: action.payload
            };
        }
        case passangerActions.EPassangerAction.LOAD_PASSANGER_SUCCESS: {
            return {
                ...state,
                passanger: action.payload
            };
        }
        case passangerActions.EPassangerAction.UPDATE_PASSANGER_SUCCESS:{
            return {
                ...state,
                passanger: action.payload
            }
        }
        case passangerActions.EPassangerAction.LOAD_PASSANGERS_BY_FLIGHT_ID_SUCCESS: {
            return { 
                ...state,
                passangers: action.payload
            };
        }
        case passangerActions.EPassangerAction.UPDATE_PASSANGER_SUCCESS: {
            return {
                ...state,
                passanger: action.payload
            }
        }
        case passangerActions.EPassangerAction.CREATE_PASSANGER_SUCCESS: {
            return {
                ...state,
                passanger: action.payload
            };
        }
        case passangerActions.EPassangerAction.LOAD_PASSANGER_BY_PID_SUCCESS: {
            return {
                ...state,
                passanger: action.payload
            };
        }
        default: {
            return state;
        }
    }
}