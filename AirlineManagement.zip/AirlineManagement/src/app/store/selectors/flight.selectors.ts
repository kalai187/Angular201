import { IAppState } from "../state/app.state";
import { createSelector} from '@ngrx/store';
import { IFlightState } from '../state/flight.state';

const selectFlights = (state: IAppState) => state.flights;

export const selectFlightList = createSelector(
    selectFlights,
    (State: IFlightState) => State.flights
)

export const selectFlight = createSelector(
    selectFlights,
    (State: IFlightState) => State.flight
)