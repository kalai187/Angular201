import { IAppState } from '../state/app.state';
import { IPassangerState } from '../state/passanger.state';
import { createSelector } from '@ngrx/store';

const selectPassangers = (state: IAppState) => state.passangers;

export const selectPassangerList = createSelector(
    selectPassangers,
    (State: IPassangerState) => State.passangers
)

export const selectPassager = createSelector(
    selectPassangers,
    (State: IPassangerState) => State.passanger
)