import { TestBed, async } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AppComponent } from './app.component';
import { SocialLoginModule} from 'angularx-social-login';

describe('AppComponent', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        SocialLoginModule
      ],
      declarations: [
        AppComponent
      ]
    }).compileComponents();
  }));
  
});
