import { Component, OnInit, ChangeDetectorRef, ChangeDetectionStrategy} from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Passanger } from 'src/app/Model/passanger.model';
import { Passport } from 'src/app/Model/passport.model';
import { Flight } from 'src/app/Model/flight.model';
import { Ancillary } from 'src/app/Model/ancillary.model';
import { Food } from 'src/app/Model/food.model';
import { Store, select } from '@ngrx/store';
import { IAppState } from 'src/app/store/state/app.state';
import { LoadPassanger, UpdatePassanger, LoadPassangersByFlightId } from 'src/app/store/actions/passanger.actions';
import { selectPassager, selectPassangerList } from 'src/app/store/selectors/passanger.selectors';
import { LoadFlight } from 'src/app/store/actions/flights.actions';
import { selectFlight } from 'src/app/store/selectors/flight.selectors';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-checkin',
  templateUrl: './checkin.component.html',
  styleUrls: ['./checkin.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class CheckinComponent implements OnInit {

  passanger$: Observable<Passanger[]>;
  passanger :Passanger;
  passport = {} as Passport;
  flight: Flight;
  ancillary: Ancillary;
  ans_key: string[] = [];
  food: Food;
  food_key:string[] = [];
  passangerId: number;
  flightId: number;
  wifi: string;
  ans_toggle : boolean = false;
  isLoaded: boolean = false;

  infant: boolean = false;
  wheel: boolean = false;
  checked: boolean = false;
  notChecked = false;

    toggle_no: string;
    toggle: boolean = false;
    first_click:string = "";
    previous_no: string;
    checked_user: boolean = false;
    is_infant: boolean = false;
    is_inf: boolean = false;
    is_wheel: boolean = false;
    is_wheell: boolean = false;

    seatmap: {} = {};
    is_seat: boolean = false;
    isshowUser: boolean = false;
    changeSeat: boolean = false;
    pass: Passanger;

  constructor(private router: Router,
              private route: ActivatedRoute,
              private store: Store<IAppState>,
              private cdr: ChangeDetectorRef) { }

  ngAfterViewChecked(){
      //your code to update the model
      this.cdr.detectChanges();
  }

  ngOnInit(): void {
    let fid = this.route.snapshot.params['fid'];
    this.store.dispatch(new LoadPassangersByFlightId(fid));
    this.passanger$ = this.store.pipe(select(selectPassangerList));

  this.passangerId = +this.route.snapshot.params['pid'];
  this.store.dispatch(new LoadPassanger(this.passangerId));
  this.store.pipe(select(selectPassager)).subscribe(
    (data: Passanger) =>{
      this.passanger = data;
      if(this.passanger != null){
        this.passport = this.passanger.passport_detail;
        this.isLoaded = true;
      }      
    }
   )
  }

  closePopup(){
    this.isshowUser = false;
  }
  
  onSelect(seat: string){

  if(this.passanger.seat_number){
    this.toggle_no = seat;
    this.changeSeat = true;
  }

    this.pass = {} as Passanger;
    this.isshowUser = false;
    if(this.seatmap[seat] != null){
      this.passanger$.subscribe(
        (data: Passanger[])=>{
          for(let item of data){
            if(item.seat_number == seat){
                this.pass = item;
                this.isshowUser = true;
              return;
            }
          }
        }
      )
    }else{
      if(this.first_click == ""){
        this.toggle_no = seat;
        this.previous_no = this.toggle_no;
        this.toggle = !this.toggle;
        this.first_click ="not first time";
      }else if(this.previous_no == seat){
        this.toggle = !this.toggle;
        this.toggle_no = '';
        this.previous_no = '';
      }else{
        this.toggle = true;
        this.toggle_no = seat;
        this.previous_no = seat;
      }
    }
    
  }

  onItemChangeInfant(value: string){
      this.is_inf = true;
    if(value == "no"){
      this.is_infant = false;
    }else{
      this.is_infant = true;
    }
  }
  onItemChangeWheel(value: string){
    this.is_wheell = true;
      if(value == "no"){
        this.is_wheel = false;
      }else{
        this.is_wheel = true;
      }
  }
 

  getAncillaryServices(){
    this.ans_key = [];
    this.food_key = [];
    this.flightId = this.route.snapshot.params['id'];
    this.store.dispatch(new LoadFlight(this.flightId));
    this.store.pipe(select(selectFlight)).subscribe(
      (data: Flight) => {
        this.flight = data;
        if(this.flight != null){
          if(this.ancillary ==  null){
            this.ancillary = this.flight.ancillary;
          }
          if(this.food == null){
            this.food = this.flight.food;
          }
          
        }
        if(this.ans_key.length == 0){
          for(let key in this.ancillary){
            this.ans_key.push(key);
          }
        }
       if(this.food_key.length == 0){
        for(let key1 in this.food){
          this.food_key.push(key1);
        }
       }
        
      }
    )
  }

  selectAncillary(key: string){
    this.ancillary = {...this.ancillary};
        if(!this.ancillary[key]){
          this.ancillary[key] = !this.ancillary[key]
        }else{
          this.ancillary[key] = !this.ancillary[key];
        }      
  }

  selectFood(key: string){
    this.food = {...this.food};
    for(let item in this.food){
      if(item == key && !this.food[key]){
          this.food[key] = true;
      }else if(item == key && this.food[key]){
          this.food[key] = true;
      }else{
        this.food[item] = false;  
      }
    }
  }

  successPage(){
    this.passanger = {...this.passanger};
    this.passanger.seat_number = this.toggle_no;
    this.passanger.ancillary = this.ancillary;
    this.passanger.food = this.food;
    this.passanger.checked_in = true;
    this.passanger.infant = this.is_infant;
    this.passanger.wheel_chair = this.is_wheel;

    this.store.dispatch(new UpdatePassanger(this.passangerId, this.passanger));
    this.store.pipe(select(selectPassager));
    this.router.navigate(['success'], {relativeTo: this.route});
  }

seat(){
  this.passanger$.subscribe(
    (data: Passanger[]) => {
      // this.checkSeatNumber(data);
      for(let item of data){
        if(item.seat_number != '' && item.wheel_chair){
          this.seatmap[item.seat_number] = "wheel_chair";
        }else if(item.seat_number != '' && !item.wheel_chair && item.infant){
          this.seatmap[item.seat_number] = "infant";
        }else if(item.seat_number != '' && !item.wheel_chair && !item.infant && item.checked_in){
          this.seatmap[item.seat_number] = 'checked_in';
        }
      }
    }

  )
  this.is_seat = true;
}

}
