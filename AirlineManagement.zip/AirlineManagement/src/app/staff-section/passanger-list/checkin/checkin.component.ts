import { Component, OnInit} from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Passanger } from 'src/app/Model/passanger.model';
import { Passport } from 'src/app/Model/passport.model';
import { Store, select } from '@ngrx/store';
import { IAppState } from 'src/app/store/state/app.state';
import { LoadPassanger, UpdatePassanger, LoadPassangersByFlightId } from 'src/app/store/actions/passanger.actions';
import { selectPassager, selectPassangerList } from 'src/app/store/selectors/passanger.selectors';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-checkin',
  templateUrl: './checkin.component.html',
  styleUrls: ['./checkin.component.scss']
})
export class CheckinComponent implements OnInit {

  passanger$: Observable<Passanger[]>;
  passanger :Passanger;
  passport = {} as Passport;
  passangerId: number;
  isLoaded: boolean = false;

    toggle_no: string;
    toggle: boolean = false;
    first_click:string = "";
    previous_no: string;
    checked_user: boolean = false;

    seatmap: {} = {};
    is_seat: boolean = false;
    isshowUser: boolean = false;
    changeSeat: boolean = false;
    pass: Passanger;
    fid: string;
    id:string;

  constructor(private router: Router,
              private route: ActivatedRoute,
              private store: Store<IAppState>) { }

  ngOnInit(): void {
    this.fid = this.route.snapshot.params['fid'];
    this.id = this.route.snapshot.params['id'];
    this.store.dispatch(new LoadPassangersByFlightId(this.fid));
    this.passanger$ = this.store.pipe(select(selectPassangerList));

  this.passangerId = +this.route.snapshot.params['pid'];
  this.store.dispatch(new LoadPassanger(this.passangerId));
  this.store.pipe(select(selectPassager)).subscribe(
    (data: Passanger) =>{
      this.passanger = data;
      if(this.passanger != null){
        this.passport = this.passanger.passport_detail;
        this.isLoaded = true;
      }      
    }
   )
  }

  closePopup(){
    this.isshowUser = false;
  }
  
  onSelect(seat: string){

  if(this.passanger.seat_number){
    this.toggle_no = seat;
    this.changeSeat = true;
  }

    this.pass = {} as Passanger;
    this.isshowUser = false;
    if(this.seatmap[seat] != null){
      this.passanger$.subscribe(
        (data: Passanger[])=>{
          for(let item of data){
            if(item.seat_number == seat){
                this.pass = item;
                this.changeSeat = false;
                this.isshowUser = true;
              return;
            }
          }
        }
      )
    }else{
      if(this.first_click == ""){
        this.toggle_no = seat;
        this.previous_no = this.toggle_no;
        this.toggle = !this.toggle;
        this.first_click ="not first time";
      }else if(this.previous_no == seat){
        this.toggle = !this.toggle;
        this.toggle_no = '';
        this.previous_no = '';
      }else{
        this.toggle = true;
        this.toggle_no = seat;
        this.previous_no = seat;
      }
    }
    
  }

  successPage(){
    this.passanger = {...this.passanger};
    this.passanger.seat_number = this.toggle_no;
    this.passanger.checked_in = true;

    this.store.dispatch(new UpdatePassanger(this.passangerId, this.passanger));
    this.store.pipe(select(selectPassager));
    this.router.navigate(['success'], {relativeTo: this.route});
  }

seat(){
  this.passanger$.subscribe(
    (data: Passanger[]) => {
      for(let item of data){
        if(item.seat_number != '' && item.wheel_chair){
          this.seatmap[item.seat_number] = "wheel_chair";
        }else if(item.seat_number != '' && !item.wheel_chair && item.infant){
          this.seatmap[item.seat_number] = "infant";
        }else if(item.seat_number != '' && !item.wheel_chair && !item.infant && item.checked_in){
          this.seatmap[item.seat_number] = 'checked_in';
        }
      }
    }

  )
  this.is_seat = true;
}

cancel(){
  this.router.navigate([this.id+"/"+this.fid+'/plist']);
}

}
