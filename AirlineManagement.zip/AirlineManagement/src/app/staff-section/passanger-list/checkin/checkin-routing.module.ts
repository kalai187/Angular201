import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { CheckinComponent } from './checkin.component';
import { AuthGuard } from 'src/app/services/Auth/auth_guard.service';

const routes: Routes = [{ path: '', component: CheckinComponent, canActivate: [AuthGuard]}, 
{ path: 'success', loadChildren: () => import('./success/success.module').then(m => m.SuccessModule) }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})

export class CheckinRoutingModule { }
