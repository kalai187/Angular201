import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CheckinRoutingModule } from './checkin-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    CheckinRoutingModule
  ]
})
export class CheckinModule { }
