import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PassangerListComponent } from './passanger-list.component';
import { AuthGuard } from 'src/app/services/Auth/auth_guard.service';

const routes: Routes = [
  { path: '', component: PassangerListComponent, canActivate: [AuthGuard] },
 { path: ':pid/checkin', loadChildren: () => import('./checkin/checkin.module').then(m => m.CheckinModule) }
]
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PassangerListRoutingModule { }
