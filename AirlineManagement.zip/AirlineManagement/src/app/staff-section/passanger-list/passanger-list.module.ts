import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PassangerListRoutingModule } from './passanger-list-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    PassangerListRoutingModule
  ]
})
export class PassangerListModule { }
