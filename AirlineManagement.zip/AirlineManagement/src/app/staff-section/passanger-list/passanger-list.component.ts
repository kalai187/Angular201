import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Passanger } from 'src/app/Model/passanger.model';
import { Store, select } from '@ngrx/store';
import { IAppState } from 'src/app/store/state/app.state';
import { Observable } from 'rxjs';
import { selectPassangerList } from 'src/app/store/selectors/passanger.selectors';
import { LoadPassangersByFlightId } from 'src/app/store/actions/passanger.actions';

@Component({
  selector: 'app-passanger-list',
  templateUrl: './passanger-list.component.html',
  styleUrls: ['./passanger-list.component.scss']
})
export class PassangerListComponent implements OnInit {

  flight_id: string;
  passangers$: Observable<Passanger[]>;
  passangers: Passanger[] = [];
  is_filter: boolean = false;

  constructor(private router: Router,
              private route: ActivatedRoute,
              private store : Store<IAppState>) { }

  ngOnInit(): void {
    this.flight_id = this.route.snapshot.params['fid'];
    this.store.dispatch(new LoadPassangersByFlightId(this.flight_id));
    this.passangers$ =  this.store.pipe(select(selectPassangerList));
        
  }

  checkInUser(index: number){
    this.router.navigate([index+'/checkin'], {relativeTo: this.route});
  }

  filterBy(e){
    this.is_filter = true;
    let property: string = e.target.value;
    this.passangers = [] as Passanger[];
    
    this.passangers$.subscribe(
      (data: Passanger[]) => {
        if(property == "passangers"){
          this.passangers = data;
        }

        this.passangers = Object.assign([], this.passangers);
        for(let item of data){
          for(let key in item){
            if(property == 'Not_checked' && !item['checked_in']){
              this.passangers.push(item);
              break;
            }else if(key == property && item[key] == true){
               this.passangers.push(item);
            }
          }
        }
      }
    )

  }

  goBack(){
    this.router.navigate(['flist']);
  }

}
