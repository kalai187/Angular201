import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Flight } from 'src/app/Model/flight.model';
import { Store, select } from '@ngrx/store';
import { IAppState } from 'src/app/store/state/app.state';
import { Observable } from 'rxjs';
import { LoadFlights, LoadFlight } from 'src/app/store/actions/flights.actions';
import { selectFlightList, selectFlight } from 'src/app/store/selectors/flight.selectors';

@Component({
  selector: 'app-flight-list',
  templateUrl: './flight-list.component.html',
  styleUrls: ['./flight-list.component.scss']
})
export class FlightListComponent implements OnInit {

  flight: Flight;
  selectedValue: string = '';
  isClicked: boolean = false;

  flights$: Observable<Flight[]>;
  flight$: Observable<Flight>;

  constructor(private router: Router,
              private route: ActivatedRoute,
              private store: Store<IAppState>) { }

  ngOnInit(): void {
    this.store.dispatch(new LoadFlights());
    this.flights$ = this.store.pipe(select(selectFlightList));
  }

  
  selected(index: number){
    this.store.dispatch(new LoadFlight(+index+1));
    this.flight$ = this.store.pipe(select(selectFlight));

    this.flight$.subscribe(
      (data: Flight) => {
        this.flight = data;
        this.isClicked = (this.flight != null);
      }
    )
  }
  getPassangerList(){
    let flightId = this.flight.flight_id;
    let id = this.flight.id;
    this.router.navigate([id+"/"+flightId+'/plist']);
  }

  goToInflight(){
    let flightId = this.flight.flight_id;
    let id = this.flight.id;
    this.router.navigate([id+"/"+flightId+'/inFlight'],{relativeTo: this.route});
  }

}
