import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Passanger } from 'src/app/Model/passanger.model';
import { Ancillary } from 'src/app/Model/ancillary.model';
import { Food } from 'src/app/Model/food.model';
import { Store, select } from '@ngrx/store';
import { IAppState } from 'src/app/store/state/app.state';
import { LoadPassangersByFlightId, UpdatePassanger } from 'src/app/store/actions/passanger.actions';
import { selectPassangerList, selectPassager } from 'src/app/store/selectors/passanger.selectors';
import { LoadFlight } from 'src/app/store/actions/flights.actions';
import { selectFlight } from 'src/app/store/selectors/flight.selectors';
import { Flight } from 'src/app/Model/flight.model';
import { ShoopingItem } from 'src/app/Model/shopping-item.model';

@Component({
  selector: 'app-passangers',
  templateUrl: './passangers.component.html',
  styleUrls: ['./passangers.component.css']
})
export class PassangersComponent implements OnInit {

  id: number;
  fid: string;
  passangers: Passanger[] = [];
  passanger: Passanger;
  flight: Flight;
  is_shopping: boolean = false;
  shoppingItems: ShoopingItem[] = [];
  shopped_items: ShoopingItem[] = [];
  shoppingItem: ShoopingItem;
  
  ancillary: Ancillary;
  ancillaries: Ancillary[] = [];
  food: Food;
  foods: Food[] = [];

  constructor(private router: Router,
              private route: ActivatedRoute,
              private store: Store<IAppState>) { }

  ngOnInit(): void {
    this.id = +this.route.snapshot.params['id'];
    this.fid = this.route.snapshot.params['fid'];

    this.store.dispatch(new LoadFlight(this.id));
    this.store.pipe(select(selectFlight)).subscribe(
      (data: Flight) => {
        this.flight = data;
      }
    )

    this.store.dispatch(new LoadPassangersByFlightId(this.fid));
    this.store.pipe(select(selectPassangerList)).subscribe(
      (data: Passanger[]) => {
        this.passangers = data;
      }
    )


  }

  addChange(index: number){
    this.ancillaries = [];
    this.foods = [];
    this.passanger = this.passangers[index];
    this.ancillary = this.passanger.ancillary;
    for(let key in this.ancillary){
      // if(this.ancillary[key]){
        this.ancillaries.push(key);
      // }
    }
    this.food = this.passangers[index].food;
    for(let key in this.food){
      // if(!this.food[key]){
        this.foods.push(key);
      // }
      
    }
  }

  selectAncillary(key: string){
    this.ancillary = {...this.ancillary};
    for(let item in this.ancillary){
      if(key == item && this.ancillary[item]){
          this.ancillary[item] = true;
      }else if(key == item && !this.ancillary[key]){
        this.ancillary[item] = true;
      }
    }
  }

  selectFood(key: string){
    this.food = {...this.food};
    for(let item1 in this.food){
      if(key == item1){
        this.food[key] = true;
      }else{
        this.food[item1] = false;
      }
    }
  }
 
  updatePreference(){
    this.passanger = {...this.passanger};
    this.passanger.ancillary = this.ancillary;
    this.passanger.food = this.food;

    this.store.dispatch(new UpdatePassanger(this.passanger.id, this.passanger));
    this.store.pipe(select(selectPassager));

    this.ngOnInit();
  }

  shoppingList(index: number){
    this.is_shopping = true;
    this.shoppingItems = this.flight.shoppingItems;
    this.passanger =  this.passangers[index];    
  }

  buyItem(index: number){
    this.passanger = {...this.passanger};
    this.shoppingItems = Object.assign([], this.shoppingItems);
    this.passanger.shopping_items = Object.assign([], this.passanger.shopping_items);
    this.shoppingItem = this.shoppingItems[index];
    let ret: boolean = false;
    for(let item of this.passanger.shopping_items){
      if(item.item == this.shoppingItems[index].item){
        ret = true;
      }
      }
      if(!ret){
        this.passanger.shopping_items.push(this.shoppingItem);
      }

    this.store.dispatch(new UpdatePassanger(this.passanger.id, this.passanger));
    this.store.pipe(select(selectPassager)).subscribe(
      (data: Passanger) => {this.passanger = data}
    );
        this.is_shopping = false;
  }


}

