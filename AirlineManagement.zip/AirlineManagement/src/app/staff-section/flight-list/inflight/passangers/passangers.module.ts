import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PassangersRoutingModule } from './passangers-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    PassangersRoutingModule
  ]
})
export class PassangersModule { }
