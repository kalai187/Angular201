import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Flight } from 'src/app/Model/flight.model';
import { IAppState } from 'src/app/store/state/app.state';
import { Store, select } from '@ngrx/store';
import { LoadFlight } from 'src/app/store/actions/flights.actions';
import { selectFlight } from 'src/app/store/selectors/flight.selectors';
import { LoadPassangersByFlightId } from 'src/app/store/actions/passanger.actions';
import { selectPassangerList } from 'src/app/store/selectors/passanger.selectors';
import { Passanger } from 'src/app/model/passanger.model';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-inflight',
  templateUrl: './inflight.component.html',
  styleUrls: ['./inflight.component.css']
})
export class InflightComponent implements OnInit {

  id: number;
  flight: Flight;
  is_loaded: boolean = false;
  is_seat: boolean = false;
  flight_id: string;
  seatmap: {} = {};
  passangers$: Observable<Passanger[]>;
  passanger : Passanger;
  isshowUser: boolean = false;

  constructor(private router: Router,
              private route: ActivatedRoute,
              private store: Store<IAppState>) { }

  ngOnInit(): void {
    this.id = +this.route.snapshot.params['id'];
    this.store.dispatch(new LoadFlight(this.id));
    this.store.pipe(select(selectFlight)).subscribe(
      (data: Flight) => {
        this.flight = data;
        this.is_loaded = (this.flight != null)
        
      }
    )

    this.flight_id = this.route.snapshot.params['fid'];
    this.store.dispatch(new LoadPassangersByFlightId(this.flight_id));
    this.passangers$ = this.store.pipe(select(selectPassangerList));
  }

  seat(){
    console.log("clicked");
    this.passangers$.subscribe(
      (data: Passanger[]) => {
          for(let item of data){
            if(item.seat_number != '' && item.food['non_veg']){
              this.seatmap[item.seat_number] = "special"
            }
          }        
      }
    )
      this.is_seat = true;  
    }

  showPassangers(){
    this.router.navigate(["passangers"],{relativeTo: this.route});
  }

  onSelect(seat: string){

    this.passangers$.subscribe(
    (data: Passanger[]) => {
      for(let item of data){
        if(item.seat_number == seat){
          this.passanger = item;
          this.isshowUser = true;
          return;
        }
      }
    }
    ); 

  }

  closePopup(){
    this.isshowUser = false;
  }

}
