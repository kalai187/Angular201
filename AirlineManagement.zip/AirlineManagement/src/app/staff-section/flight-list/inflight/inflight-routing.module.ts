import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { InflightComponent } from './inflight.component';
import { AuthGuard } from 'src/app/services/Auth/auth_guard.service';

const routes: Routes = [{ path: '', component: InflightComponent, canActivateChild: [AuthGuard]},
 { path: 'passangers', loadChildren: () => import('./passangers/passangers.module').then(m => m.PassangersModule)},];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class InflightRoutingModule { }
