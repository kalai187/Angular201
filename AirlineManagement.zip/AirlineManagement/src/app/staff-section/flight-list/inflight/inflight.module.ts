import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { InflightRoutingModule } from './inflight-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    InflightRoutingModule
  ]
})
export class InflightModule { }
