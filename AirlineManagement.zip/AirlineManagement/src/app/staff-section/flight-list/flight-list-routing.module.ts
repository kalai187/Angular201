import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { FlightListComponent } from './flight-list.component';
import { AuthGuard } from 'src/app/services/Auth/auth_guard.service';

const routes: Routes = [{ path: '', component: FlightListComponent},
{ path: ':id/:fid/inFlight', loadChildren: () => import('./inflight/inflight.module').then(m => m.InflightModule) }, 
]
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FlightListRoutingModule { }
