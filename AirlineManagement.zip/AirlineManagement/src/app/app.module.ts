import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { LoginComponent } from './login/login.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MaterialModule } from './material/material.module';
import { FlightListComponent } from './staff-section/flight-list/flight-list.component';
import { PassangerListComponent } from './staff-section/passanger-list/passanger-list.component';
import { CheckinComponent } from './staff-section/passanger-list/checkin/checkin.component';
import { SuccessComponent } from './staff-section/passanger-list/checkin/success/success.component';
import { InflightComponent } from './staff-section/flight-list/inflight/inflight.component';
import { PassangersComponent } from './staff-section/flight-list/inflight/passangers/passangers.component';
import { HttpClientModule } from '@angular/common/http';
import { FlightServices } from './services/flight.services';
import { PassengerService } from './services/passanger.services';
import { DashboardComponent } from './admin-section/dashboard/dashboard.component';
import { CreatePassangerComponent } from './admin-section/passanger-section/create-passanger/create-passanger.component';
import { UpdatePassangerComponent } from './admin-section/passanger-section/update-passanger/update-passanger.component';
import { StoreModule } from '@ngrx/store';
import { appReducers } from './store/reducers/app.reducers';
import { EffectsModule } from '@ngrx/effects';
import { FlightEffect } from './store/effects/flights.effects';
import { PassangerEffects } from './store/effects/passanger.effects';
import { environment } from 'src/environments/environment';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { CreateAncillaryComponent } from './admin-section/ancillary-section/create-ancillary/create-ancillary.component';
import { SocialLoginModule, GoogleLoginProvider } from 'angularx-social-login';
import { FacebookLoginProvider, SocialAuthServiceConfig } from 'angularx-social-login';
import { IteratePipe } from './pipe/iterate.pipe';
import { LoginServices } from './services/login.service';
import { AuthGuard } from './services/Auth/auth_guard.service';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    FlightListComponent,
    PassangerListComponent,
    CheckinComponent,
    SuccessComponent,
    InflightComponent,
    PassangersComponent,
    DashboardComponent,
    CreatePassangerComponent,
    UpdatePassangerComponent,
    CreateAncillaryComponent,
    IteratePipe
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    SocialLoginModule,
    MaterialModule,
    HttpClientModule,
    StoreModule.forRoot(appReducers),
    EffectsModule.forRoot([FlightEffect, PassangerEffects]),
    !environment.production ? StoreDevtoolsModule.instrument() : []
    
  ],
  providers: [FlightServices, PassengerService,LoginServices,AuthGuard,
    {
      provide: 'SocialAuthServiceConfig',
      useValue: {
        autoLogin: false,
        providers: [
          {
            id: FacebookLoginProvider.PROVIDER_ID,
            provider: new FacebookLoginProvider('2628386210761658'),
          },
          {
            id: GoogleLoginProvider.PROVIDER_ID,
            provider: new GoogleLoginProvider(
              '410357571464-kt9d91ec9kkhnqgaa0ms62old29371oo.apps.googleusercontent.com')
          }
        ],
      } as SocialAuthServiceConfig,
    },],
  bootstrap: [AppComponent]
})
export class AppModule { }
