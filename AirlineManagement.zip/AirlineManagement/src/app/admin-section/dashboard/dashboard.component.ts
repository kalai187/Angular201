import { Component, OnInit} from '@angular/core';
import { Router } from '@angular/router';
import { Flight } from 'src/app/Model/flight.model';
import { Store, select } from '@ngrx/store';
import { IAppState } from 'src/app/store/state/app.state';
import { Observable } from 'rxjs';
import { LoadFlight, LoadFlights } from 'src/app/store/actions/flights.actions';
import { selectFlight, selectFlightList } from 'src/app/store/selectors/flight.selectors';
import { LoadPassangersByFlightId } from 'src/app/store/actions/passanger.actions';
import { selectPassangerList } from 'src/app/store/selectors/passanger.selectors';
import { Passanger } from 'src/app/model/passanger.model';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})

export class DashboardComponent implements OnInit{

  // flights: Flight[];
  flights$: Observable<Flight[]>;
  passangers$: Observable<Passanger[]>;
  passangers : Passanger[] = [];
  isSelected: boolean = false;
  isAncillary: boolean = false
  isPassanger: boolean = false;
  id: number;
  flight_id: string = '';
  is_filter: boolean = false;
  is_loaded: boolean = false;
  is_dissable: boolean = false;


  constructor(private router: Router,
              private store: Store<IAppState>) { }

  ngOnInit(): void {
    this.store.dispatch(new LoadFlights);
    this.flights$ = this.store.pipe(select(selectFlightList));

  }

  // Choose city using select dropdown
  selectFlight(e) {
    this.is_dissable = true;
    this.isSelected = true;
    this.isAncillary = false;
    this.isPassanger = false;
    this.id = +e.target.value+1;
    this.store.dispatch(new LoadFlight(this.id));
    this.store.pipe(select(selectFlight)).subscribe(
      (data: Flight) => {
        if(data != null){
          console.log("called");
          this.flight_id = data.flight_id;
        }
        
      }
    )
      
  }

getPassangers(){
  this.passangers = [] as Passanger[];
  this.is_dissable = false;
  this.store.dispatch(new LoadPassangersByFlightId(this.flight_id));
     this.passangers$ = this.store.pipe(select(selectPassangerList));
     this.is_loaded = true;   
}

  manage(property: string){
    if(property == "passanger"){
      this.isPassanger = true;
     
    }else{
      this.isAncillary = true;
    }
}
createPassanger(){  this.router.navigate([this.id+"/"+this.flight_id+'/create-passanger']);}
UpdatePassanger(pid: number){this.router.navigate([this.id+"/"+this.flight_id+'/update/'+pid]);}
createAncillary(){  this.router.navigate([this.id+"/"+this.flight_id+'/create-ancillary']);}
updateAncillary(){  this.router.navigate([this.id+"/"+this.flight_id+'/update-ancillary']);}


filterBy(e){
  let property:string = e.target.value;
  this.passangers = [] as Passanger[];
  this.passangers$.subscribe(
    (data: Passanger[]) => {
      if(property == "passangers"){
        this.passangers = data;
      }
      
      this.passangers = Object.assign([], this.passangers);
      
      for(let item of data){

        if(property == 'birth_date' && item.birth_date == ''){
          this.passangers.push(item);
        }
        
       
        if(property == 'passport'){
          for(let pass in item.passport_detail){
            if(item.passport_detail[pass] == ''){
              this.passangers.push(item);
              break;
            }
        }
       }

       if(property == 'address'){
        for(let addr in item.address){
        if(item.address[addr] == ''){
          this.passangers.push(item);
          break;
        }
       }
       }
      }
      this.is_filter = (this.passangers != null);
    }
  )
}

}
