import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Store, select } from '@ngrx/store';
import { IAppState } from 'src/app/store/state/app.state';
import { LoadFlight, UpdateFlight } from 'src/app/store/actions/flights.actions';
import { Flight } from 'src/app/Model/flight.model';
import { selectFlight } from 'src/app/store/selectors/flight.selectors';
import { Ancillary } from 'src/app/Model/ancillary.model';
import { Food } from 'src/app/Model/food.model';
import { ShoopingItem } from 'src/app/Model/shopping-item.model';

@Component({
  selector: 'app-create-ancillary',
  templateUrl: './create-ancillary.component.html',
  styleUrls: ['./create-ancillary.component.scss']
})
export class CreateAncillaryComponent implements OnInit {

  id: number;
  flight : Flight;
  is_loaded: boolean = false;
  ancillar: Ancillary;
  food: Food;
  ancillary: Ancillary[] = [];
  foods: Food[] = [];
  shopping_item = {} as ShoopingItem;
  shopping_items: ShoopingItem[] = [];

  is_service: boolean = false;
  is_food: boolean = false;
  is_item: boolean = false;
  isshow: boolean = false;
  
  @ViewChild('name', {static: false}) name:ElementRef;
  @ViewChild('food', {static: false}) foodName:ElementRef;
  @ViewChild('item', {static: false}) itemName:ElementRef;
  @ViewChild('quantity', {static: false}) quantity:ElementRef;
  @ViewChild('price', {static: false}) price:ElementRef;

  constructor(private router: Router,
              private route: ActivatedRoute,
              private store: Store<IAppState>) { }

  ngOnInit(): void {
    this.id = +this.route.snapshot.params['id'];
    this.store.dispatch(new LoadFlight(this.id));
    this.store.pipe(select(selectFlight)).subscribe(
      (data: Flight) => {
        this.flight = data;
        
        if(this.flight != null){
          this.ancillar = this.flight.ancillary;
          this.food = this.flight.food; 
          this.shopping_items = this.flight.shoppingItems;
        }
        
        this.ancillary = [] as Ancillary[];
        this.foods = [] as Food[];
        for(let item in this.ancillar){
          this.ancillary.push(item);
        }
        for(let item in this.food){
          this.foods.push(item);
        }
        this.is_loaded = (this.flight != null);
      }
    )
    
  }

  deteteAncillary(key: string){
    this.ancillar = Object.assign({}, this.ancillar)
    this.flight = Object.assign({} , this.flight);
    delete this.ancillar[key];
    this.flight.ancillary = this.ancillar;
    console.log(this.flight.ancillary);
    this.store.dispatch(new UpdateFlight(this.id, this.flight));
    this.store.pipe(select(selectFlight)).subscribe(
      (data: Flight) => {
        this.flight = data;
        console.log(this.flight);
      }
    )
    console.log(this.flight);
  }
  deteteFood(key: string){
    this.food = {...this.food},
    this.flight = {...this.flight};
    delete this.food[key];
    this.flight.food = this.food;

    this.store.dispatch(new UpdateFlight(this.id, this.flight));
    this.store.pipe(select(selectFlight)).subscribe(
      (data: Flight) => {
        this.flight = data;
      }
    )
  }

  add(property: string){
    if(property == 'service'){
      this.is_service = true;
      this.is_item = false;
      this.is_food = false;
    }else if(property == "food"){
      this.is_service = false;
      this.is_item = false;
      this.is_food = true;
    }else{
      this.is_service = false;
      this.is_item = true;
      this.is_food = false;
    }
  }


  AddAncillary(){
    this.flight = {...this.flight};
    let ancillar = {} as Ancillary;
    
    let name: string = this.name.nativeElement.value;
    
    if(name != ''){
      for(let item in this.flight.ancillary){
        if(item != name){
          ancillar[item] = false;
        }else{
          return;
        }
       
      }

    ancillar[name] = false;
    this.flight.ancillary = ancillar;
    this.store.dispatch(new UpdateFlight(this.id,this.flight));
    this.store.pipe(select(selectFlight)).subscribe(
    (data: Flight) => {
     this.flight = data;
  }
)
this.name.nativeElement.value = "";
}
}

addFood(){
  this.flight = {...this.flight};
  let food = {} as Food;
  
  let name: string = this.foodName.nativeElement.value;
  
  if(name != ''){
    for(let item in this.flight.food){
      if(item != name){
        food[item] = false;
      }else{
        return;
      }
     
    }

  food[name] = false;
  this.flight.food = food;
  this.store.dispatch(new UpdateFlight(this.id,this.flight));
  this.store.pipe(select(selectFlight)).subscribe(
  (data: Flight) => {
   
}
)
this.foodName.nativeElement.value = "";
}
}

addItem(){
  let item = this.itemName.nativeElement.value;
  let qty = +this.quantity.nativeElement.value;
  let price = +this.price.nativeElement.value;

  if(item && qty && price){
    this.flight = {...this.flight};
    this.shopping_item = {} as ShoopingItem;
    this.shopping_item['item'] = item;
    this.shopping_item['quantity'] = qty;
    this.shopping_item['price'] = price;

    this.shopping_items = Object.assign([], this.shopping_items);
    this.shopping_items.push(this.shopping_item);

    this.flight.shoppingItems = this.shopping_items;

    this.flight.shoppingItems = this.shopping_items;
    this.store.dispatch(new UpdateFlight(this.id,this.flight));
    this.store.pipe(select(selectFlight)).subscribe(
      (data: Flight) => {
        this.flight = data;
      }
    )
    this.itemName.nativeElement.value = "";
    this.quantity.nativeElement.value = "";
    this.price.nativeElement.value = "";
  }else{
    return;
  }
}
deleteItem(index: number){
  this.flight = {...this.flight};
  this.shopping_items = Object.assign([], this.shopping_items);
  this.shopping_items.splice(index,1);
  this.flight.shoppingItems = this.shopping_items;

  this.store.dispatch(new UpdateFlight(this.id,this.flight));
  this.store.pipe(select(selectFlight)).subscribe(
    (data: Flight) => {;
      this.flight = data;
    }
  )
}

updateItem(index: number){
  this.shopping_item = {} as ShoopingItem;
this.shopping_item = this.shopping_items[index];

}
updateItemService(data, index: number){
  this.flight = {...this.flight};
  this.shopping_items = Object.assign([], this.shopping_items);

  this.shopping_item = data.value;
  this.shopping_items[index] = this.shopping_item;

  this.flight.shoppingItems = this.shopping_items;

  this.store.dispatch(new UpdateFlight(this.id, this.flight));
  this.store.pipe(select(selectFlight)).subscribe(
    (data: Flight) => {
    })
}

updateAncillary(){
  this.ancillar = {} as Ancillary;
  this.ancillar = this.flight.ancillary;

}
UpdateService(data){
  this.flight = {...this.flight};
  this.ancillar = {...this.ancillar};
  let ans = {} as Ancillary;
  for(let item in data.value){
    ans[data.value[item]] = false;
  }
  this.ancillar = ans;
  this.flight.ancillary = this.ancillar;
  this.store.dispatch(new UpdateFlight(this.id, this.flight));
  this.store.pipe(select(selectFlight)).subscribe(
    (data: Flight) => {
    }
  )

}

updateFood(){
  this.food = {} as Food;
  this.food = this.flight.food;

}

updateFoodService(data){

  this.flight = {...this.flight};
  this.food = {...this.food};
  let fod = {} as Food;
  for(let item in data.value){
    fod[data.value[item]] = false;
  }
  this.food = fod;
  this.flight.food = this.food;
  this.store.dispatch(new UpdateFlight(this.id, this.flight));
  this.store.pipe(select(selectFlight)).subscribe(
    (data: Flight) => {
    }
  )
}

prevPage(){
  this.router.navigate(['dashboard']);
}


}
