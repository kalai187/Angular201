import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { CreateAncillaryComponent } from './create-ancillary.component';
import { AuthGuard } from 'src/app/services/Auth/auth_guard.service';

const routes: Routes = [{ path: '', component: CreateAncillaryComponent, canActivateChild: [AuthGuard]}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CreateAncillaryRoutingModule { }
