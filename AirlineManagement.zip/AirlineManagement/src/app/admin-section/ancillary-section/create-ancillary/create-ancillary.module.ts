import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CreateAncillaryRoutingModule } from './create-ancillary-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    CreateAncillaryRoutingModule
  ]
})
export class CreateAncillaryModule { }
