import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreatePassangerComponent } from './create-passanger.component';
import { DebugElement } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CreatePassangerRoutingModule } from './create-passanger-routing.module';
import { By } from '@angular/platform-browser';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { StoreModule } from '@ngrx/store';
import { RouterTestingModule } from '@angular/router/testing';
import { appReducers } from 'src/app/store/reducers/app.reducers';
import { environment } from 'src/environments/environment';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { Flight } from 'src/app/Model/flight.model';
import { DashboardComponent } from '../../dashboard/dashboard.component';
import { IteratePipe } from 'src/app/pipe/iterate.pipe';

describe('CreatePassangerComponent', () => {
  let component: CreatePassangerComponent;
  let fixture: ComponentFixture<CreatePassangerComponent>;
  let de: DebugElement;
  let el: HTMLElement;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreatePassangerComponent, DashboardComponent,IteratePipe],
      imports: [
        CommonModule,
        CreatePassangerRoutingModule,
        FormsModule,
        ReactiveFormsModule,
        RouterTestingModule.withRoutes([
          { path: 'dashboard', component: DashboardComponent },
        ]),
        StoreModule.forRoot(appReducers),
        !environment.production ? StoreDevtoolsModule.instrument() : []
      ],
      
      providers: []
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreatePassangerComponent);
    component = fixture.componentInstance;
    component.flight = {} as Flight;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should be submitted true', async(() =>{
    component.onSubmit();
    expect(component.submitted).toBeTruthy();
  }))

  it('button click should call onSubmit method', async(() => {
    fixture.detectChanges();
    spyOn(component, 'onSubmit');
    el = fixture.debugElement.query(By.css('button')).nativeElement;
    el.click();
    expect(component.onSubmit).toHaveBeenCalledTimes(0);
  }));

  //ANY ONE FIELD IS EMPTY
  it('form shoild not be valid', async(() =>{
    component.registerForm.controls['namee'].setValue('');
    expect(component.registerForm.invalid).toBeTruthy();
  }))

  it('form shoild be valid', async(() =>{
    component.registerForm.controls['namee'].setValue('kalai');
    expect(component.registerForm.valid).toBeTruthy();
  }))

});
