import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreatePassangerComponent } from './create-passanger.component';
import { DebugElement } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CreatePassangerRoutingModule } from './create-passanger-routing.module';
import { By } from '@angular/platform-browser';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { Store, StoreModule } from '@ngrx/store';
import { RouterTestingModule } from '@angular/router/testing';
import { appReducers } from 'src/app/store/reducers/app.reducers';
import { EffectsModule } from '@ngrx/effects';
import { FlightEffect } from 'src/app/store/effects/flights.effects';
import { PassangerEffects } from 'src/app/store/effects/passanger.effects';
import { environment } from 'src/environments/environment';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { Flight } from 'src/app/Model/flight.model';
import { DashboardComponent } from '../../dashboard/dashboard.component';

describe('CreatePassangerComponent', () => {
  let component: CreatePassangerComponent;
  let fixture: ComponentFixture<CreatePassangerComponent>;
  let de: DebugElement;
  let el: HTMLElement;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreatePassangerComponent, DashboardComponent],
      imports: [
        CommonModule,
        CreatePassangerRoutingModule,
        FormsModule,
        ReactiveFormsModule,
        RouterTestingModule.withRoutes([
          { path: 'dashboard', component: DashboardComponent },
        ]),
        StoreModule.forRoot(appReducers),
        !environment.production ? StoreDevtoolsModule.instrument() : []
      ],
      
      providers: []
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreatePassangerComponent);
    component = fixture.componentInstance;
    component.flight = {} as Flight;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should be submitted true', async(() =>{
    component.onSubmit();
    expect(component.submitted).toBeTruthy();
  }))

  it('button click should call onSubmit method', async(() => {
    fixture.detectChanges();
    spyOn(component, 'onSubmit');
    el = fixture.debugElement.query(By.css('button')).nativeElement;
    el.click();
    expect(component.onSubmit).toHaveBeenCalledTimes(0);
  }));

  //ANY ONE FIELD IS EMPTY
  it('form shoild not be valid', async(() =>{
    component.registerForm.controls['namee'].setValue('kalai');
    component.registerForm.controls['dob'].setValue('07-06-1993');
    component.registerForm.controls['street'].setValue('southStreet');
    component.registerForm.controls['door'].setValue('138');
    component.registerForm.controls['state'].setValue('TamilNadu');
    component.registerForm.controls['country'].setValue('India');
    component.registerForm.controls['passport_number'].setValue('45454545445454');
    component.registerForm.controls['pancard'].setValue('');
    component.registerForm.controls['expire_date'].setValue('12/25');
    expect(component.registerForm.invalid).toBeTruthy();
  }))

  it('form shoild be valid', async(() =>{
    component.registerForm.controls['namee'].setValue('kalai');
    component.registerForm.controls['dob'].setValue('07-06-1993');
    component.registerForm.controls['street'].setValue('southStreet');
    component.registerForm.controls['door'].setValue('138');
    component.registerForm.controls['state'].setValue('TamilNadu');
    component.registerForm.controls['country'].setValue('India');
    component.registerForm.controls['passport_number'].setValue('45454545445454');
    component.registerForm.controls['pancard'].setValue('GGDDD4543');
    component.registerForm.controls['expire_date'].setValue('12/25');
    expect(component.registerForm.valid).toBeTruthy();
  }))

});
