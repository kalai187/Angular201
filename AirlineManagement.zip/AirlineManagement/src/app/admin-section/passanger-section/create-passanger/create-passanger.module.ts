import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CreatePassangerRoutingModule } from './create-passanger-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    CreatePassangerRoutingModule
  ]
})
export class CreatePassangerModule { }
