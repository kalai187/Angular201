import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { Flight } from 'src/app/Model/flight.model';
import { Passanger } from 'src/app/Model/passanger.model';
import { Passport } from 'src/app/Model/passport.model';
import { Ancillary } from 'src/app/Model/ancillary.model';
import { Food } from 'src/app/Model/food.model';
import { ShoopingItem } from 'src/app/Model/shopping-item.model';
import { Address } from 'src/app/Model/address.model';
import { Store, select } from '@ngrx/store';
import { IAppState } from 'src/app/store/state/app.state';
import { LoadFlight } from 'src/app/store/actions/flights.actions';
import { selectFlight } from 'src/app/store/selectors/flight.selectors';
import { CreatePassanger } from 'src/app/store/actions/passanger.actions';
import { selectPassager } from 'src/app/store/selectors/passanger.selectors';

@Component({
  selector: 'app-create-passanger',
  templateUrl: './create-passanger.component.html',
  styleUrls: ['./create-passanger.component.scss']
})
export class CreatePassangerComponent implements OnInit {

  registerForm: FormGroup;
  submitted = false;
  flight: Flight;
  id: number;
  name: string;
  passanger = {} as Passanger;
  passport = {} as Passport;
  ancillary = {} as Ancillary;
  food = {} as Food;
  shoppingItem: ShoopingItem[] = [];
  address = {} as Address;
 

  constructor(private formBuilder: FormBuilder,
              private router: Router,
              private route: ActivatedRoute,
              private store: Store<IAppState>) { }

  ngOnInit(): void {
    this.id = +this.route.snapshot.params['id'];

    this.store.dispatch(new LoadFlight(this.id));
    this.store.pipe(select(selectFlight)).subscribe(
      (data: Flight) => {
        if(data != null){
          this.flight = data;
          this.food = this.flight.food;
          this.ancillary = this.flight.ancillary;
        }
      }
    )

    this.registerForm = this.formBuilder.group({
      namee: ['', Validators.required],
      door: [''],
      state: [''],
      street: [''],
      country: [''],
      dob: [''],
      passport_number: [''],
      pancard: [''],
      expire_date: [''],
      infant:[''],
      wheel_chair:[''],
      food:['']
    })
}

selectAncillary(property: string){
  this.ancillary = {...this.ancillary};
  for(let key in this.ancillary){
    if(key == property && this.ancillary[key]){
      this.ancillary[key] = false;
    }else if(key == property && !this.ancillary[key]){
      this.ancillary[key] = true;
    }
  }
}

 onSubmit() {

     this.submitted = true; 
     
    this.address.door_no = this.registerForm.value.door;
    this.address.street = this.registerForm.value.street;
    this.address.state = this.registerForm.value.state;
    this.address.country = this.registerForm.value.country;

    this.passport.passport_number = this.registerForm.value.passport_number;
    this.passport.pan_card = this.registerForm.value.pancard;
    this.passport.expire_date = this.registerForm.value.expire_date;

    this.passanger.name = this.registerForm.value.namee;
    this.passanger.birth_date = this.registerForm.value.dob;
    this.passanger.passport_detail = this.passport;
    this.passanger.address = this.address;
    this.passanger.seat_number = '';
     this.passanger.checked_in = false;
     this.passanger.passport_detail = this.passport;
     this.passanger.ancillary = this.ancillary;
     this.passanger.shopping_items = this.shoppingItem;
     this.passanger.flight_id = this.flight.flight_id;
   
    this.food = {...this.food};
    for(let key in this.food){
      if(key == this.registerForm.value.food){
        this.food[key] = true;
      }else{
        this.food[key] = false;
      }
    }

     this.passanger.food = this.food;
    if(this.registerForm.value.infant == "yes"){
      this.passanger.infant = true;
    }else{
      this.passanger.infant = false;
    }

    if(this.registerForm.value.wheel_chair == "yes"){
        this.passanger.wheel_chair = true;
    }else{
      this.passanger.wheel_chair = false;
    }

    this.store.dispatch(new CreatePassanger(this.passanger));
    this.store.pipe(select(selectPassager)).subscribe(
      (data: Passanger) => {
      }
    )
    this.router.navigate(['dashboard']);
 }

 onReset() {
     this.submitted = false;
     this.registerForm.reset();
     this.router.navigate(['dashboard']);
 }
}
