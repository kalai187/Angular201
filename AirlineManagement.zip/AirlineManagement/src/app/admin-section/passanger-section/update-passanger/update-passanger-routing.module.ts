import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { UpdatePassangerComponent } from './update-passanger.component';
import { AuthGuard } from 'src/app/services/Auth/auth_guard.service';

const routes: Routes = [{ path: '', component: UpdatePassangerComponent, canActivate: [AuthGuard]}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UpdatePassangerRoutingModule { }
