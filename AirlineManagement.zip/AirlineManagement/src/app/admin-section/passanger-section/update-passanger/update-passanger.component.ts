import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Passanger } from 'src/app/Model/passanger.model';
import { Flight } from 'src/app/Model/flight.model';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Passport } from 'src/app/Model/passport.model';
import { Address } from 'src/app/Model/address.model';
import { Store, select } from '@ngrx/store';
import { IAppState } from 'src/app/store/state/app.state';
import { LoadPassangersByFlightId, UpdatePassanger, LoadPassanger } from 'src/app/store/actions/passanger.actions';
import { selectPassangerList, selectPassager } from 'src/app/store/selectors/passanger.selectors';

@Component({
  selector: 'app-update-passanger',
  templateUrl: './update-passanger.component.html',
  styleUrls: ['./update-passanger.component.css']
})
export class UpdatePassangerComponent implements OnInit {

  passanger: Passanger;
  passport = {} as Passport;
  address = {} as Address;
  pid: number;
  is_loaded: boolean = false;

  formData: FormGroup;
  submitted = false;

  constructor(private router: Router,
              private route: ActivatedRoute,
              private formBuilder: FormBuilder,
              private store: Store<IAppState>) { }

  ngOnInit(): void {
   
    this.pid = +this.route.snapshot.params['pid'];

    this.store.dispatch(new LoadPassanger(this.pid));
    this.store.pipe(select(selectPassager)).subscribe(
      (data: Passanger) => {
        this.passanger = data;
        this.is_loaded = (this.passanger != null);
      }
    )
  
    this.formData = this.formBuilder.group({
      name: ['', Validators.required],
      door: ['', Validators.required],
      state: ['', Validators.required],
      street: ['', Validators.required],
      country: ['', Validators.required],
      dob: ['', Validators.required],
      passport_number: ['', Validators.required ],
      pancard: ['', Validators.required],
      expire_date: ['', Validators.required]
    })

  }

  onSubmit(data) {
    this.submitted = true;
    this.address = {...this.address};
    this.passport = {...this.passport};
    this.passanger = {...this.passanger};

    if(data.door != ''){
      this.address.door_no = data.door;
    }else{
      this.address.door_no = this.passanger.address.door_no;
    }

    if(data.street != ''){
      this.address.street = data.street;
    }else{
      this.address.street = this.passanger.address.street;
    }

    if(data.state != ''){
      this.address.state = data.state;
    }else{
      this.address.state = this.passanger.address.state;
    }

    if(data.country != ''){
      this.address.country = data.country;
    }else{
      this.address.country = this.passanger.address.country;
    }

    if(data.passport_number != ''){
      this.passport.passport_number = data.passport_number;
    }else{
      this.passport.passport_number = this.passanger.passport_detail.passport_number;
    }

    if(data.pancard != ''){
      this.passport.pan_card = data.pancard;
    }else{
      this.passport.pan_card = this.passanger.passport_detail.pan_card;
    }

    if(data.expire_date != ''){
      this.passport.expire_date = data.expire_date;
    }else{
      this.passport.expire_date = this.passanger.passport_detail.expire_date;
    }

    if(data.name != ''){
      this.passanger.name = data.name;
    }else{
      this.passanger.name = this.passanger.name;
    }

    if(data.dob != ''){
      this.passanger.birth_date = data.dob
    }else{
      this.passanger.birth_date = this.passanger.birth_date;
    }
    
    this.passanger.address = this.address;
    this.passanger.passport_detail = this.passport;

    this.store.dispatch(new UpdatePassanger(this.passanger.id,this.passanger));
    this.store.pipe(select(selectPassager)).subscribe(
      (data: Passanger) =>{
       this.router.navigate(['dashboard']);
        
      }
    )
  }

}
