import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Passanger } from 'src/app/Model/passanger.model';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Passport } from 'src/app/Model/passport.model';
import { Address } from 'src/app/Model/address.model';
import { Store, select } from '@ngrx/store';
import { IAppState } from 'src/app/store/state/app.state';
import { UpdatePassanger, LoadPassanger} from 'src/app/store/actions/passanger.actions';
import { selectPassager } from 'src/app/store/selectors/passanger.selectors';
import { Observable } from 'rxjs';
import { Food } from 'src/app/Model/food.model';
import { Ancillary } from 'src/app/Model/ancillary.model';

@Component({
  selector: 'app-update-passanger',
  templateUrl: './update-passanger.component.html',
  styleUrls: ['./update-passanger.component.scss']
})
export class UpdatePassangerComponent implements OnInit {

  // passanger$: Observable<Passanger>;
  passanger: Passanger;
  passport = {} as Passport;
  address = {} as Address;
  pid: number;
  food = {} as Food;
  food_key: string[] = [];
  is_loaded: boolean = false;
  ancillary= {} as Ancillary;

  formData: FormGroup;
  submitted = false;

  constructor(private router: Router,
              private route: ActivatedRoute,
              private formBuilder: FormBuilder,
              private store: Store<IAppState>) { }

  ngOnInit(): void {
   
    this.pid = +this.route.snapshot.params['pid'];
    console.log(this.pid);
    this.store.dispatch(new LoadPassanger(this.pid));
    this.store.pipe(select(selectPassager)).subscribe(
      (data: Passanger) => {
        this.passanger = data;
        this.is_loaded = (this.passanger != null);
        for(let item in this.passanger){
          if(item == "ancillary"){
            this.ancillary = this.passanger[item];
          }
        }
      }
    );

    this.formData = this.formBuilder.group({
      name: ['', Validators.required],
      door: [''],
      state: [''],
      street: [''],
      country: [''],
      dob: [''],
      passport_number: [''],
      pancard: [''],
      expire_date: [''],
      infant:[''],
      wheel_chair:[''],
      food:['']
    });

  }

  selectAncillary(property: string){
    this.ancillary = {...this.ancillary};
    for(let item in this.ancillary){
      if(item == property && this.ancillary[item]){
        this.ancillary[item] = false;
      }else if(item == property && !this.ancillary[item]){
        this.ancillary[item] = true;
      }
    }
  }

  onSubmit(data) {

    this.submitted = true;
    this.address = {...this.address};
    this.passport = {...this.passport};
    this.passanger = {...this.passanger};

    if(data.door != ''){
      this.address.door_no = data.door;
    }else{
      this.address.door_no = this.passanger.address.door_no;
    }

    if(data.street != ''){
      this.address.street = data.street;
    }else{
      this.address.street = this.passanger.address.street;
    }

    if(data.state != ''){
      this.address.state = data.state;
    }else{
      this.address.state = this.passanger.address.state;
    }

    if(data.country != ''){
      this.address.country = data.country;
    }else{
      this.address.country = this.passanger.address.country;
    }

    if(data.passport_number != ''){
      this.passport.passport_number = data.passport_number;
    }else{
      this.passport.passport_number = this.passanger.passport_detail.passport_number;
    }

    if(data.pancard != ''){
      this.passport.pan_card = data.pancard;
    }else{
      this.passport.pan_card = this.passanger.passport_detail.pan_card;
    }

    if(data.expire_date != ''){
      this.passport.expire_date = data.expire_date;
    }else{
      this.passport.expire_date = this.passanger.passport_detail.expire_date;
    }

    if(data.name != ''){
      this.passanger.name = data.name;
    }else{
      this.passanger.name = this.passanger.name;
    }

    if(data.dob != ''){
      this.passanger.birth_date = data.dob
    }else{
      this.passanger.birth_date = this.passanger.birth_date;
    }
    
    this.passanger.address = this.address;
    this.passanger.passport_detail = this.passport;

    if(data.infant != '' && data.infant == "yes"){
      this.passanger.infant = true;
    }else if(data.infant != '' && data.infant == 'no'){
      this.passanger.infant = false;
    }

    if(data.wheel_chair != '' && data.wheel_chair == "yes"){
      this.passanger.wheel_chair = true;
    }else if(data.wheel_chair != '' && data.wheel_chair == 'no'){
      this.passanger.wheel_chair = false;
    }
    if(data.food != ''){
      this.food = {...this.food};
    for(let key in this.passanger.food){
      if(key == data.food){
        this.food[key] = true;
      }else{
        this.food[key] = false;
      }
    }
    this.passanger.food = this.food;
    }
    this.passanger.ancillary = this.ancillary;
    this.store.dispatch(new UpdatePassanger(this.passanger.id,this.passanger));
    this.store.pipe(select(selectPassager)).subscribe(
      (data: Passanger) =>{
        
      }
    )
    this.router.navigate(['dashboard']);
  }

  cancel() {
    this.submitted = false;
    this.router.navigate(['dashboard']);
}

}
