import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { UpdatePassangerRoutingModule } from './update-passanger-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    UpdatePassangerRoutingModule
  ]
})
export class UpdatePassangerModule { }
