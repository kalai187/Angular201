import { Component, OnInit} from '@angular/core';
import { Router } from '@angular/router';
import { SocialUser, SocialAuthService, GoogleLoginProvider, FacebookLoginProvider } from 'angularx-social-login';
import { LoginServices } from '../services/login.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  user: SocialUser;
  loggedIn: boolean;

  username: string = '';
  password: string = '';

  adminUserName: string = "admin";
  adminPassword: string = "admin";

  staffUserName: string = "staff";
  staffPassword: string = "staff";


  constructor(private router: Router,
              private authService: SocialAuthService,
              private loginService: LoginServices) { }

              
  ngOnInit(): void {
    // this.authService.authState.subscribe((user) => {
    //   this.user = user;
    //   this.loggedIn = (this.user != null);
    //   if(this.loggedIn && !this.loginService.socialLogin){
    //     console.log("login triggered");
    //     this.router.navigate(['flist']);
    //     this.loginService.changeLoginStatus("LogOut");
    //     this.loginService.changeSocialLogin(true);
    //   }
    // });
  }

  
  normalLogin(data){
    let user: string = '';
    let pass: string = '';
    user = data.value['username'];
    pass = data.value['password'];
    
    if(user == this.adminUserName && pass == this.adminPassword){
      this.router.navigate(['dashboard']);
      this.loginService.changeLoginStatus("LogOut");
    }else if(user == this.staffUserName && pass == this.staffPassword){
      this.router.navigate(['flist']);
      this.loginService.changeLoginStatus("LogOut");
    }
  }

  signInWithGoogle(): void {
    this.authService.signIn(GoogleLoginProvider.PROVIDER_ID);
    this.authService.authState.subscribe((user) => {
      this.user = user;
      this.loggedIn = (this.user != null);
      if(this.loggedIn){
        this.router.navigate(['flist']);
        this.loginService.changeLoginStatus("LogOut");
        this.loginService.changeSocialLogin(true);
      }
    });
    
  }
 
  signInWithFB(): void {
    this.authService.signIn(FacebookLoginProvider.PROVIDER_ID);
    this.authService.authState.subscribe((user) => {
      this.user = user;
      this.loggedIn = (this.user != null);
      if(this.loggedIn){
        this.router.navigate(['flist']);
        this.loginService.changeLoginStatus("LogOut");
        this.loginService.changeSocialLogin(true);
      }
    });
  }

  logout(){
    this.authService.signOut();
  }

}
