import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { AuthGuard } from './services/Auth/auth_guard.service';


const routes: Routes = [
  { path: '',   redirectTo: '/login', pathMatch: 'full' },
  { path: 'login', component: LoginComponent},
  { path: 'flist',canActivate: [AuthGuard], loadChildren: () => 
  import('./staff-section/flight-list/flight-list.module').then(m => m.FlightListModule)},
  { path: ':id/:fid/plist',canActivate: [AuthGuard], loadChildren: () => 
  import('./staff-section/passanger-list/passanger-list.module').then(m => m.PassangerListModule)},
  { path: 'dashboard',canActivate: [AuthGuard], loadChildren: () => 
  import('./admin-section/dashboard/dashboard.module').then(m => m.DashboardModule)},
  { path: ':id/:fid/create-ancillary',canActivate: [AuthGuard], loadChildren: () => 
  import('./admin-section/ancillary-section/create-ancillary/create-ancillary.module').then(m => m.CreateAncillaryModule)},
  { path: ':id/:fid/update/:pid',canActivate: [AuthGuard], loadChildren: () => 
  import('./admin-section/passanger-section/update-passanger/update-passanger.module').then(m => m.UpdatePassangerModule)},
  { path: ':id/:fid/create-passanger',canActivate: [AuthGuard], loadChildren: () => 
  import('./admin-section/passanger-section/create-passanger/create-passanger.module').then(m => m.CreatePassangerModule)},
  { path: '**', redirectTo: '/login' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
