import { Component, OnInit } from '@angular/core';
import { LoginServices } from './services/login.service';
import { Router } from '@angular/router';
import { SocialAuthService } from 'angularx-social-login';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit{
  title: string = 'AirlineManagement';
  logStatus: string = "LogIn";

  constructor(private loginservice: LoginServices,
              private router: Router,
              private authService: SocialAuthService){}


  ngOnInit(){
  }

  onActivate() {
    console.log("app component");
    this.logStatus = this.loginservice.loginStatus;
  }

  logout(){
    
    if(this.loginservice.socialLogin){
      this.authService.signOut();
      this.loginservice.changeLoginStatus("LogIn");
      this.loginservice.changeSocialLogin(false);
      this.router.navigate(['login']);
    }else{
      this.loginservice.changeLoginStatus("LogIn");
      this.router.navigate(['login']);
    }
  }
}
