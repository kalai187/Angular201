GuideLines For Airline Management Application

LoginCredential For : 
Admin : 
	username: admin
	password: admin
Staff : 
        username: staff
	password: staff


How to start an Application:
1.Exrtrat the Zip file.

2.import the Airline Management app to the Visual studio code

3. To start json server :
   3.1. Open terminal in visual studio
   3.2. Enter "npm run api"

4. To start an Application :
   4.1. open one more terminal
   4.2. Enter "ng serve --ssl"

5.Once Application and json server started open your browser then,
  5.1. Enter "https://localhost:4200/"


GuideLines to use Application as Admin:
1.Use admin credentials for login
2.you will get dashboard page, Select flight from flight list
3.Click get passangerList button
4. you will get passanger list with button to update passanger for selected flight and three options
   4.1. Create Passanger
   4.2. Update Passanger
   4.2. Create Ancillary

   4.1 Create Passanger : 
	4.1.1. click create Passanger
	4.1.2. provide details and click create
	4.1.3. passanger will get added and you can see it in passanger list
	4.1.4. click reset button to reset the form
	4.1.5. Once successfully created. you will be redirected to the dashboard page

    4.2 Update Passanger : 
	4.2.1. click update passanger from passanger List
	4.2.1. update details and click Update passanger
	4.2.3. passanger will get update and you can see it in passanger list
	4.1.4.Once successfully update. you will get redirected to the dashboard page
	
    4.3 Create Ancillary : 
	Once you click Create Ancillary button you can able to see three buttons 
	4.3.1. Manage Ancillary
	4.3.2. Manage Food
	4.3.3. Mangage Item
	
	4.3.1. Manage Ancillary : 
	       4.3.1.1. click manage Ancillary
  	       4.3.1.2. here you can Create, Update and Delete Ancillary
	       4.3.1.3. To create enter name in text field. cleck Add Ancillary
	       4.3.1.4. To delete an Ancillary. click on Ancillary name ion the table.
	       4.3.1.5. To update click update button. edit name of the Ancillary, click update button
	4.3.2. Manage Food : 
	       4.3.2.1. click manage Food
  	       4.3.2.2. here you can Create, Update and Delete Food
	       4.3.2.3. To create enter name in text field. cleck Add Food
	       4.3.2.4. To delete an Foodclick on Food name ion the table.
	       4.3.2.5. To update click update button. edit name of the Food, click update button
	4.3.3. Manage Item :  
	       4.3.3.1. click manage Item
  	       4.3.3.2. here you can Create, Update and Delete Item
	       4.3.3.3. To create enter name in text field. cleck Add Item
	       4.3.3.4. To delete an Item click the delete button
	       4.3.3.5. To update click update button. edit name of the Item, click update button
    
    4.4 Filter Missing Requirments from passanger: 
	4.4.1. In dashboard above the passanger list table you can see the filter links
	4.4.2. you can Filter the passanger by clicking Passport, Address and Date Of Birth
	


GuideLines to use Application as Staff:
1.Use staff credentials and social login for login
2.You will get dashboard page, Select flight from flight list
3.You will get two buttons along with flight detail table
  3.1. Book Passanger
  3.2. InflightDetails

  3.1. Book Passanger :
	3.1.1. Click Book Passanger
	3.1.2. You can see passanger list and Filters(checkedin/not/infant/wheelchair)
	3.1.3. Checked in passangers will get Change seat button in table
	3.1.4. Not checked passangers will have a option to checkin button in tabel
       CheckedIn Passanger: 
	   1. Click on changeseat button from passanger list
	   2. Click show map
	   3. Select seat which is not booked(you can diffrentiate with color code)
	   4. Confirm booking and select ancillary services and food then submit
	   5. Passanger seat will be changed
	   6. Click Go back you will be redirected to dashboard
	Not checkedIn Passanger :
	   1. Click on checkin button from passanger list
	   2. Click show map
	   3. Select seat which is not booked(you can diffrentiate with color code)
	   4. Confirm booking and select ancillary services and food then submit
	   5. Passanger will be changed in
	   6. Click Go back you will be redirected to dashboard
	
 	** To checkin select a button to deselect click onemore time **
   	** For Reserved tickets click the seats you will get the passanger name and ancillary services**

   3.2. Inflight Preferances
	3.2.1. Click InflightDetail button
	3.2.2. you will be able to see selected flight details table and two buttons
	    1. Show seatmap
	    2. Show PassangerList
	1. ShowMap :	
	   3.2.3. Click Showmap you can see seatmap with colorcode specifying special meal requested by passanger.
	   3.2.3. When you click on color coded seat it will show the user name and food prefernce
	2. Show PassangerList : 
	   3.2.4. Click show passanger button
	   3.2.5. You can see passanger list along with that two buttons
		1. Add/Change
		2. ShopItem
           1. Add/Change : 
  		3.2.5. Click Add/Change button
		3.2.6. Change ancillary services and food preferences for a passanger
		3.2.7. Click submit changes will be shown in the passanger list
	   2. Shop Item :
		3.2.8. Click shopItem and click buy to buy an item for a passanger
		3.2.9. Shopped Item will be visible in the passangers list 

Guide To Test An Application : 
    1. Open new terminal in visual studio.
    2. Enter "ng test". 
    3. This will open a browser there you can see the test cases details.


*********************************************************** Thanks *************************************************************************

 
